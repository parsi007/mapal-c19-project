var START=2
var PLAY=1
var END=0
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var bananaGroup, obGroup
var score
var jungle,jungleImage
var invisibleline
var gameState=START
var survivalTime=0
var bananaTaken=0
var jail,jailImage
var snake,snakeImage,sGroup
var bsound


function preload(){
 monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png") 
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
  jungleImage=loadImage("jungle.jpg")
  jailImage=loadImage("jail.png")
  snakeImage=loadImage("s1.png")
  bsound=loadSound("banana.mp3")
 
  
}



function setup() {

  createCanvas(600,500)
  
  jungle=createSprite(500,200,250,20)
  jungle.addImage(jungleImage)
  jungle.scale=1.2
  jungle.x= jungle.width /2;
  jungle.velocityX=-3
  

  monkey=createSprite(80,380,20,20)
  monkey.addAnimation("running",monkey_running)
  monkey.scale=0.2
  
  invisibleline=createSprite(0,475,1500,20)
  invisibleline.visible=false
  
  jail=createSprite(100,350,20,20)
  jail.addImage(jailImage)
  jail.scale=0.4
  
  bananaGroup= new Group();
  obGroup= new Group();
  sGroup= new Group()
}


function draw() {
  
  
  
  switch(score){
    case 10 :player.scale=0.12;
             break;
      case 20 :player.scale=0.14;
             break;
             
      case 30 :player.scale=0.16;
             break; 
             
      case 40 :player.scale=0.18;
             break;
      
    default:break;
             
  }
  

  
  if(gameState===START){
    background("green")
    jungle.visible=false
    
    textSize(18)
    fill("white")
    text("Hi,I am King Kong.I want to escape from the Jail of the Monkey Zoo. ",50,150)
    text("I AM WAITING :)",250,210)
    text("Press 'S' to help Me and to START the GAME",50,180)
    
     textSize(32)
    textFont("Bradley Hand ITC Bold")
    text("Welcome To Monkey Go Happy Game",72,100)
    
    textFont("Bradley Hand ITC")
    textSize(25)
    text("How to PLAY:",230,250)
    text("1. Press SPACE key to Jump",230,270)
    text("2.Collect the Bananas ",230,293)
    text("3.Beware of obstacles and Snakes ",230,315)
    
    
    
    if(keyDown("S")){
      gameState=PLAY
      jail.destroy()
    }
  }
if(gameState===PLAY){
  jungle.visible=true
  if (jungle.x < 0){
      jungle.x = jungle.width/2;
    }
  
  if(keyDown("space")){
    monkey.velocityY=-4
  }
  
  monkey.velocityY = monkey.velocityY + 0.8
  
  monkey.collide(invisibleline)

  spawnBanana()
  spawnObstacle() 
  spawnSnakes()
  
   survivalTime=survivalTime+Math.round(getFrameRate()/60);
  
  if(monkey.isTouching(bananaGroup)){
    bananaGroup.destroyEach();
    bananaTaken=bananaTaken+1
    monkey.scale=0.2
    bsound.play()
  }
   if(monkey.isTouching(obGroup)){
    obGroup.destroyEach();
     monkey.scale=monkey.scale-0.1
  }
  if(monkey.scale===0){
    gameState=END
  }
  
   if(monkey.isTouching(sGroup)){
    sGroup.destroyEach();
   
     gameState=END
  }
  
} 
  
  else if(gameState===END){
   monkey.visible=false

    jungle.velocityX=0
    bananaGroup.destroyEach();
    obGroup.destroyEach();
    sGroup.destroyEach();
    jungle.visible=false
    background("black")
    
    textSize(62)
    fill("white")
    text("You lose!",200,250)
  }
  
drawSprites();
 
 
  textSize(20)
  fill("white")
  text("Survival Time :" + survivalTime,30,50)
  
  text("Banana Eaten :" + bananaTaken,400,50)
}

function spawnBanana(){
  
  if(frameCount%90===0){
    banana=createSprite(50,80,20,20)
    banana.x=Math.round(random(470,490));
    banana.y=Math.round(random(90,150))
    banana.addImage(bananaImage)
    banana.scale=0.1
    banana.velocityX=-5
    banana.lifetime=300
    bananaGroup.add(banana)
    }
}

function spawnObstacle(){
  
  if(frameCount%170===0){
    obstacle=createSprite(50,424,20,20)
    obstacle.x=Math.round(random(495,500));
    obstacle.addImage(obstacleImage)
    obstacle.scale=0.3
    obstacle.velocityX=-5
    obstacle.lifetime=300
    obGroup.add(obstacle);
    }
}

function spawnSnakes(){
  
  if(frameCount%150===0){
    snake=createSprite(50,40,20,20)
    snake.x=Math.round(random(105,450));
    snake.addImage(snakeImage)
    snake.scale=0.2
    snake.velocityY=3
    snake.lifetime=300
    sGroup.add(snake);
    }
}



